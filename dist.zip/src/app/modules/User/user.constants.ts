export const USER_Role = {
  admin: 'admin',
  user: 'user',
  super_admin: 'super_admin',
} as const;
